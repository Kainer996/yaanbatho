#!/usr/bin/python3
"""Native, single-instance, read-only download dashboard."""
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Adw, Gdk, Gio, GLib, Gtk, Pango
from monitor import Monitor, size

APP_ID = 'local.download.Monitor'
LABELS = {'running': 'Receiving', 'paused': 'Paused', 'queued': 'Queued · waiting', 'setup_required': 'Download setup needed', 'interrupted': 'Interrupted', 'incomplete': 'Incomplete · not running', 'failed': 'Failed', 'unknown': 'Unknown', 'completed': 'Completed', 'cancelled': 'Cancelled'}
CSS = b'''
window { background: #10191e; color: #edf5f5; }
headerbar { background: #10191e; box-shadow: none; }
.hero { font-size: 30px; font-weight: 800; letter-spacing: -0.8px; }
.muted { color: #a4b6bf; }
.eyebrow { color: #6edcc1; font-size: 11px; font-weight: 800; letter-spacing: 1.4px; }
.counter { background: #19272e; border-radius: 13px; padding: 13px 17px; }
.count { font-size: 28px; font-weight: 750; }
.card { background: #1a282f; border: 1px solid #2b3d46; border-radius: 14px; padding: 17px 19px; }
.filename { font-size: 16px; font-weight: 700; }
.badge { border-radius: 7px; padding: 5px 9px; font-size: 11px; font-weight: 750; background: #34444d; color: #d9e4e8; }
.running, .completed { background: #19483d; color: #85ebca; }
.paused { background: #514524; color: #ffe294; }
.queued, .setup_required { background: #303c58; color: #bfceff; }
.incomplete, .interrupted, .failed { background: #533c31; color: #ffc39b; }
.bytes { font-size: 13px; font-weight: 650; }
progressbar trough { min-height: 7px; border-radius: 8px; background: #30424c; }
progressbar progress { min-height: 7px; border-radius: 8px; background: #6edcc1; }
.attention-progress progress { background: #d6a376; }
.unknown-progress trough { background-image: repeating-linear-gradient(135deg, #405763 0px, #405763 6px, #2d404a 6px, #2d404a 12px); }
.filters button { border-radius: 8px; padding: 6px 13px; }
.filters button:checked { background: #31554e; color: #c7fff1; }
.coverage { background: #16232a; border-radius: 12px; padding: 13px 16px; }
'''


def label(text='', css=None, wrap=False):
    widget = Gtk.Label(label=text, xalign=0)
    if css:
        widget.add_css_class(css)
    widget.set_wrap(wrap)
    widget.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
    return widget


def box(orientation=Gtk.Orientation.VERTICAL, spacing=8):
    return Gtk.Box(orientation=orientation, spacing=spacing)


def open_folder(path):
    directory = Path(path)
    if not directory.is_dir():
        directory = directory.parent
    if directory.is_dir():
        Gio.AppInfo.launch_default_for_uri(directory.as_uri(), None)


class Card(Gtk.Box):
    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add_css_class('card')
        row = box(Gtk.Orientation.HORIZONTAL, 10)
        self.name = label(css='filename')
        self.name.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
        self.name.set_hexpand(True)
        self.badge = label(css='badge')
        row.append(self.name)
        row.append(self.badge)
        self.append(row)
        self.origin = label(css='muted')
        self.origin.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
        self.append(self.origin)
        self.progress = Gtk.ProgressBar()
        self.progress.set_pulse_step(.12)
        self.append(self.progress)
        info = box(Gtk.Orientation.HORIZONTAL, 12)
        self.bytes = label(css='bytes')
        self.bytes.set_hexpand(True)
        self.percent = label(css='muted')
        info.append(self.bytes)
        info.append(self.percent)
        self.append(info)
        self.detail = label(css='muted', wrap=True)
        self.append(self.detail)
        self.source_link = Gtk.LinkButton.new_with_label('https://www.blackmagicdesign.com/products/davinciresolve', 'View official source')
        self.source_link.set_halign(Gtk.Align.START)
        self.source_link.set_visible(False)
        self.append(self.source_link)
        self.item = None
        self.old_status = None
        click = Gtk.GestureClick()
        click.connect('released', self.clicked)
        self.add_controller(click)

    def clicked(self, gesture, count, x, y):
        if count == 2 and self.item and self.item.path:
            open_folder(self.item.path)

    def update(self, item):
        self.item = item
        self.name.set_text(item.name)
        self.name.set_tooltip_text(item.name)
        if self.old_status:
            self.badge.remove_css_class(self.old_status)
        self.badge.add_css_class(item.status)
        self.old_status = item.status
        self.badge.set_text(LABELS.get(item.status, 'Unknown'))
        queued = item.status in ('queued', 'setup_required')
        location = item.path.replace(str(Path.home()), '~', 1) if item.path else 'No saved file location'
        self.origin.set_text(item.source if queued else f'{item.source}  ·  {location}')
        self.origin.set_tooltip_text(item.path or location)
        self.detail.set_text(item.detail)
        self.source_link.set_visible(bool(item.website) and queued)
        if item.website:
            self.source_link.set_uri(item.website)
        self.progress.set_visible(not queued)
        if queued:
            self.bytes.set_text('Not started')
            self.percent.set_text('After ' + item.dependency if item.status == 'queued' else 'Official setup required')
        elif item.fraction is not None:
            self.progress.remove_css_class('unknown-progress')
            self.progress.set_fraction(item.fraction)
            self.percent.set_text(f'{item.fraction:.1%}')
            self.bytes.set_text(f'{size(item.received)} / {size(item.total)} {item.metric}')
        else:
            if item.status == 'running':
                self.progress.remove_css_class('unknown-progress')
                self.progress.pulse()
            else:
                self.progress.set_fraction(0)
                self.progress.add_css_class('unknown-progress')
            self.percent.set_text('Total unknown')
            self.bytes.set_text(f'{size(item.received)} {item.metric}' if item.received is not None else 'Received bytes unknown')
        if item.speed and item.status == 'running':
            self.bytes.set_text(self.bytes.get_text() + f'  ·  {size(item.speed)}/s file growth')
        raw = f'{item.received:,} bytes {item.metric}' if item.received is not None else 'Received bytes unavailable'
        if item.total:
            raw += f' / {item.total:,} total bytes'
        self.bytes.set_tooltip_text(raw)
        if item.status in ('incomplete', 'interrupted', 'paused', 'failed'):
            self.progress.add_css_class('attention-progress')
        else:
            self.progress.remove_css_class('attention-progress')
        self.progress.set_tooltip_text('Total size unavailable; the segment is not a percentage.' if item.fraction is None else f'{item.fraction:.2%}')

    def animate(self):
        if self.item and self.item.status == 'running' and self.item.fraction is None:
            self.progress.pulse()


class Dashboard(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        self.window = None
        self.monitor = Monitor()
        self.cards = {}
        self.items = []
        self.busy = False
        self.filter = 'all'
        self.generation = 0

    def do_activate(self):
        if self.window:
            self.window.present()
            self.focus_hyprland()
            return
        self.generation += 1
        Adw.StyleManager.get_default().set_color_scheme(Adw.ColorScheme.FORCE_DARK)
        provider = Gtk.CssProvider()
        provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_display(Gdk.Display.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self.window = Adw.ApplicationWindow(application=self)
        self.window.set_title('Download Monitor')
        self.window.set_default_size(840, 590)
        self.window.set_size_request(560, 430)
        self.window.connect('close-request', self.on_close)
        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect('key-pressed', self.on_key)
        self.window.add_controller(keys)
        layout = box(spacing=0)
        header = Adw.HeaderBar()
        header.set_decoration_layout(':close')
        header.set_title_widget(label('Download Monitor'))
        folder = Gtk.Button(icon_name='folder-download-symbolic', tooltip_text='Open Downloads folder')
        folder.connect('clicked', lambda *_: open_folder(self.monitor.downloads))
        header.pack_start(folder)
        self.coverage_button = Gtk.ToggleButton(label='Coverage')
        header.pack_end(self.coverage_button)
        layout.append(header)
        body = box(spacing=16)
        for method in ('set_margin_start', 'set_margin_end'):
            getattr(body, method)(26)
        body.set_margin_bottom(18)
        body.set_margin_top(8)
        body.append(label('YOUR DOWNLOADS, IN VIEW', 'eyebrow'))
        top = box(Gtk.Orientation.HORIZONTAL, 10)
        title = label('Download Monitor', 'hero')
        title.set_hexpand(True)
        top.append(title)
        self.live = label('●  Connecting', 'muted')
        top.append(self.live)
        body.append(top)
        self.summary = label('Checking local download sources…', 'muted', wrap=True)
        body.append(self.summary)
        metrics = box(Gtk.Orientation.HORIZONTAL, 10)
        self.counts = []
        for name in ('Receiving', 'Paused', 'Needs attention', 'Finished'):
            metric = box(spacing=2)
            metric.add_css_class('counter')
            metric.set_hexpand(True)
            value = label('0', 'count')
            metric.append(value)
            metric.append(label(name, 'muted'))
            self.counts.append(value)
            metrics.append(metric)
        body.append(metrics)
        filters = box(Gtk.Orientation.HORIZONTAL, 6)
        filters.add_css_class('filters')
        first = None
        for key, text in (('all', 'All'), ('queue', 'Queue'), ('active', 'Receiving & paused'), ('attention', 'Needs attention'), ('finished', 'History')):
            button = Gtk.ToggleButton(label=text)
            if first:
                button.set_group(first)
            else:
                first = button
            button.connect('toggled', self.filter_changed, key)
            filters.append(button)
        first.set_active(True)
        body.append(filters)
        self.revealer = Gtk.Revealer(transition_type=Gtk.RevealerTransitionType.SLIDE_DOWN)
        coverage = box(spacing=8)
        coverage.add_css_class('coverage')
        coverage.append(label('What this monitor can see', 'filename'))
        coverage.append(label('Browser history supplies received bytes, totals and recorded completion, cancellation or interruption. Browser pause switches are usually not saved there: an unfinished, motionless record stays Unknown.', 'muted', wrap=True))
        coverage.append(label('Terminal file outputs: curl, wget, wget2 and aria2c across folders; other writers and partial files in Downloads. Other writer processes are discovered within 15 seconds; file sizes refresh every 2 seconds. Paused means an explicitly suspended writer. Plain terminal commands do not expose total size or final exit status. aria2 allocation is not counted as received bytes.', 'muted', wrap=True))
        coverage.append(label('Other apps, private browser sessions, torrents and package managers have no dedicated integration. Files appearing in Downloads may be visible, but this is not complete system-wide coverage. Monitoring runs while this window is open; closing it leaves transfers alone.', 'muted', wrap=True))
        coverage.append(label('The saved queue preserves downloads waiting for dependencies and official-source setup. It does not run transfers automatically. A dependency is never cleared by inactivity: a matching browser completion record, complete byte count and ZIP end directory are required. Terminal-only downloads need separate completion verification.', 'muted', wrap=True))
        self.sources_label = label('', 'muted', wrap=True)
        coverage.append(self.sources_label)
        self.revealer.set_child(coverage)
        self.coverage_button.connect('toggled', lambda button: self.revealer.set_reveal_child(button.get_active()))
        self.listbox = box(spacing=12)
        content = box(spacing=12)
        content.append(self.revealer)
        content.append(self.listbox)
        self.empty = label('No downloads in this view.', 'muted', wrap=True)
        self.empty.set_margin_top(24)
        content.append(self.empty)
        scroll = Gtk.ScrolledWindow(hexpand=True, vexpand=True)
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_child(content)
        body.append(scroll)
        body.append(label('Refreshes every 2 seconds  ·  Hover over sizes for exact bytes  ·  Esc to close', 'muted', wrap=True))
        layout.append(body)
        body.set_vexpand(True)
        self.window.set_content(layout)
        self.window.present()
        self.refresh()
        GLib.timeout_add(2000, self.refresh_timer, self.generation)
        GLib.timeout_add(180, self.animate, self.generation)

    def focus_hyprland(self):
        if os.environ.get('HYPRLAND_INSTANCE_SIGNATURE'):
            # Fixed class match only; no arbitrary command or user data interpolation.
            subprocess.Popen(['hyprctl', 'dispatch', 'hl.dsp.focus({ window = "class:^local.download.Monitor$" })'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def on_close(self, *_):
        self.window = None
        self.cards = {}
        self.quit()
        return False

    def on_key(self, controller, keyval, keycode, state):
        if keyval == Gdk.KEY_Escape:
            self.window.close()
            return True
        return False

    def filter_changed(self, button, key):
        if button.get_active():
            self.filter = key
            if hasattr(self, 'listbox'):
                self.render()

    def refresh_timer(self, generation):
        if not self.window or generation != self.generation:
            return False
        self.refresh()
        return True

    def animate(self, generation):
        if not self.window or generation != self.generation:
            return False
        for card in self.cards.values():
            card.animate()
        return True

    def refresh(self):
        if self.busy:
            return
        self.busy = True
        generation = self.generation
        def work():
            try:
                result = self.monitor.poll()
                GLib.idle_add(self.apply, generation, result, False)
            except Exception:
                # Error strings from OS/database inputs never reach logs or UI.
                GLib.idle_add(self.apply, generation, None, True)
        threading.Thread(target=work, daemon=True).start()

    def apply(self, generation, result, error):
        self.busy = False
        if not self.window or generation != self.generation:
            return False
        if error:
            self.live.set_text('●  Refresh unavailable')
            self.summary.set_text('Could not refresh observations. Retrying in 2 seconds; visible data may be stale.')
            for item in self.items:
                if item.status in ('running', 'paused'):
                    item.status = 'unknown'
                    item.speed = None
                    item.detail = 'Last observation; monitor refresh is unavailable.'
            self.render()
            return False
        self.items, sources = result
        self.live.set_text('●  Live · ' + time.strftime('%H:%M:%S'))
        self.sources_label.set_text('Detected sources\n' + '\n'.join(sources))
        active = sum(item.status == 'running' for item in self.items)
        attention = sum(item.status in ('interrupted', 'failed', 'incomplete', 'unknown') for item in self.items)
        queued = sum(item.status in ('queued', 'setup_required') for item in self.items)
        self.summary.set_text(f'{active} observed transfer' + ('s' if active != 1 else '') + ' receiving. ' + (f'{queued} queued. ' if queued else '') + (f'{attention} item' + ('s need' if attention != 1 else ' needs') + ' attention or has an unknown status.' if attention else 'All other observed records are shown below.'))
        self.render()
        return False

    def render(self):
        counts = [sum(x.status == 'running' for x in self.items), sum(x.status == 'paused' for x in self.items), sum(x.status in ('unknown', 'incomplete', 'failed', 'interrupted') for x in self.items), sum(x.status in ('completed', 'cancelled') for x in self.items)]
        for widget, count in zip(self.counts, counts):
            widget.set_text(str(count))
        visible = []
        for item in self.items:
            if self.filter == 'queue' and item.status not in ('queued', 'setup_required'):
                continue
            if self.filter == 'active' and item.status not in ('running', 'paused'):
                continue
            if self.filter == 'attention' and item.status not in ('unknown', 'incomplete', 'failed', 'interrupted'):
                continue
            if self.filter == 'finished' and item.status not in ('completed', 'cancelled'):
                continue
            visible.append(item)
        wanted = {x.id for x in visible}
        for key in list(self.cards):
            if key not in wanted:
                self.listbox.remove(self.cards.pop(key))
        previous = None
        for item in visible:
            if item.id not in self.cards:
                self.cards[item.id] = Card()
                self.listbox.append(self.cards[item.id])
            card = self.cards[item.id]
            card.update(item)
            self.listbox.reorder_child_after(card, previous)
            previous = card
        self.empty.set_visible(not visible)


if __name__ == '__main__':
    GLib.set_prgname(APP_ID)
    if '--snapshot' in sys.argv:
        import dataclasses
        items, sources = Monitor().poll()
        print(json.dumps({'downloads': [dataclasses.asdict(x) for x in items], 'sources': sources}, indent=2))
    else:
        sys.exit(Dashboard().run(sys.argv))

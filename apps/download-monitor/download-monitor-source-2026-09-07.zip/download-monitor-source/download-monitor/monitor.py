"""Read-only download observations. Never read command lines, URLs, or cookies."""
from __future__ import annotations

import dataclasses
import json
import os
from pathlib import Path
import shutil
import sqlite3
import stat
import tempfile
import time
from urllib.parse import urlsplit


@dataclasses.dataclass
class Download:
    id: str
    name: str
    path: str = ""
    source: str = ""
    status: str = "unknown"
    received: int | None = None
    total: int | None = None
    detail: str = ""
    updated: float = 0
    metric: str = "received"
    speed: float | None = None
    website: str = ""
    dependency: str = ""

    @property
    def fraction(self):
        if self.total and self.received is not None:
            return max(0, min(1, self.received / self.total))
        return None


def size(value):
    if value is None:
        return "Unknown"
    n = float(value)
    for unit in ["B", "KiB", "MiB", "GiB", "TiB"]:
        if abs(n) < 1024 or unit == "TiB":
            return f"{n:,.0f} {unit}" if unit == "B" else f"{n:,.2f} {unit}"
        n /= 1024


def stamp(path):
    result = []
    for suffix in ("", "-wal", "-journal"):
        try:
            s = Path(str(path) + suffix).stat()
            result.append((s.st_ino, s.st_size, s.st_mtime_ns))
        except FileNotFoundError:
            result.append(None)
    return tuple(result)


def download_rows(path):
    """Short SQLite read; stable private snapshot for Electron's exclusive lock.

    Only explicit download columns are selected. No immutable reads of live WAL
    databases, no writes to the browser, and no lingering SQLite connections.
    """
    def query(connection):
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA query_only=ON")
        columns = {r[1] for r in connection.execute("PRAGMA table_info(downloads)")}
        if not columns:
            return []
        required = {"id", "current_path", "target_path", "received_bytes", "total_bytes", "state", "start_time"}
        if not required.issubset(columns):
            raise ValueError("Unsupported download database schema")
        # Most Chromium builds do not persist pause state in History.
        pause = "paused" if "paused" in columns else "NULL AS paused"
        reason = "interrupt_reason" if "interrupt_reason" in columns else "0 AS interrupt_reason"
        fields = f"id,current_path,target_path,received_bytes,total_bytes,state,start_time,{reason},{pause}"
        rows = connection.execute(f"SELECT {fields} FROM downloads WHERE state IN (0,3)").fetchall()
        rows += connection.execute(f"SELECT {fields} FROM downloads WHERE state NOT IN (0,3) ORDER BY start_time DESC LIMIT 100").fetchall()
        return [dict(row) for row in rows]

    try:
        connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=.08)
        try:
            return query(connection)
        finally:
            connection.close()
    except sqlite3.OperationalError as exc:
        if "locked" not in str(exc) and "busy" not in str(exc):
            raise
    # Copy only when unchanged across the copy. A hot rollback journal is unsafe.
    for _ in range(2):
        before = stamp(path)
        if before[2] and before[2][1] > 0:
            # Exclusive-lock Chromium retains a committed, zeroed journal.
            # A nonzero journal header may need rollback; never copy that state.
            with Path(str(path) + '-journal').open('rb') as journal:
                header = journal.read(8)
            if header and any(header):
                raise ValueError("Browser database is busy; retrying next refresh")
        if sum(x[1] for x in before if x) > 128 * 1024 * 1024:
            raise ValueError("Locked browser database exceeds snapshot limit")
        with tempfile.TemporaryDirectory(prefix="download-monitor-") as directory:
            target = Path(directory) / "History"
            for suffix in ("", "-wal"):
                source = Path(str(path) + suffix)
                if source.exists():
                    shutil.copyfile(source, str(target) + suffix)
            if stamp(path) != before:
                continue
            connection = sqlite3.connect(target, timeout=.08)
            try:
                return query(connection)
            finally:
                connection.close()
    raise ValueError("Browser database changed during snapshot; retrying")


def browser_status(state, paused=None, growing=False):
    if state == 1:
        return "completed", "Browser reports completion."
    if state == 2:
        return "cancelled", "Browser reports cancellation."
    if state == 3:
        return "interrupted", "Browser reports an interrupted download."
    if state == 0 and paused == 1:
        return "paused", "Browser explicitly reports a pause."
    if state == 0 and growing:
        return "running", "Received byte count is increasing."
    if state == 0:
        return "unknown", "Browser has an unfinished record. Pause / waiting / stopped cannot be distinguished from history."
    return "unknown", "Unrecognized browser state."


def zip_end_present(path):
    # Bounded footer inspection, cached by size and mtime. Never read a GB archive.
    try:
        with path.open("rb") as handle:
            handle.seek(max(0, path.stat().st_size - 65557))
            tail = handle.read(65557)
        pos = tail.rfind(b"PK\x05\x06")
        if pos < 0 or pos + 22 > len(tail):
            return False
        length = int.from_bytes(tail[pos + 20:pos + 22], "little")
        return pos + 22 + length == len(tail)
    except OSError:
        return None


def dependency_completed(path, observations, writers):
    """Conservative evidence gate; inactivity and a ZIP footer alone never pass.

    A matching successful browser record must agree with the actual complete
    file length. Terminal-only archives require separate completion verification
    outside this monitor; no completion is inferred from a vanished process.
    """
    path = Path(path)
    if not path.is_absolute() or path.is_symlink() or str(path) in writers:
        return False
    try:
        before = path.stat()
        if not stat.S_ISREG(before.st_mode) or before.st_size <= 0:
            return False
        matching = [item for item in observations if item.id.startswith('browser:')
                    and item.path == str(path) and item.status == 'completed'
                    and item.total == before.st_size and item.received == item.total]
        if not matching or zip_end_present(path) is not True:
            return False
        after = path.stat()
        return (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    except OSError:
        return False


def queued_downloads(queue_file, observations, writers):
    """Render persistent requests; deliberately has no transfer execution path.

    This version preserves requests blocked by official-source setup. Even if
    a dependency completes, the item still requires setup rather than starting.
    Queue content is data, never executable commands or signed URLs.
    """
    try:
        with Path(queue_file).open() as stream:
            document = json.load(stream)
    except FileNotFoundError:
        return []
    if document.get('version') != 1 or not isinstance(document.get('items'), list):
        raise ValueError('Unsupported queue format')
    result = []
    for entry in document['items'][:100]:
        if not isinstance(entry, dict) or entry.get('state') != 'queued':
            continue
        dependency = entry.get('wait_for', {})
        path = dependency.get('path', '')
        if not path or not Path(path).is_absolute():
            raise ValueError('Queue dependency must name an absolute file')
        source = entry.get('source', {})
        website = source.get('page', '')
        url = urlsplit(website)
        if (url.scheme != 'https' or url.netloc != 'www.blackmagicdesign.com'
                or url.query or url.fragment or not url.path.startswith('/products/')):
            raise ValueError('Queue source must be an official product page')
        complete = dependency_completed(path, observations, writers)
        name = str(dependency.get('name', 'Previous download'))[:120]
        if complete:
            status = 'setup_required'
            detail = f'{name} has matching completion evidence. Official download setup is still required; this item has not started.'
        else:
            status = 'queued'
            detail = f'Waiting for verified completion of {name}. A stopped process or unchanged file does not release this queue.'
        detail += ' ' + str(source.get('blocker', 'Official download setup is required.'))[:900]
        detail += ' Automatic start is not configured.'
        result.append(Download(id='queue:' + str(entry['id'])[:120],
                               name=str(entry['name'])[:180], source='Blackmagic Design · free Linux edition',
                               status=status, detail=detail, updated=float(entry.get('created_at', 0)),
                               website=website, dependency=name))
    return result


class Monitor:
    def __init__(self, home=None, downloads=None, proc=None, state_dir=None):
        self.home = Path(home or Path.home())
        self.downloads = Path(downloads or self._downloads_directory())
        self.proc = Path(proc or "/proc")
        self.state_dir = Path(state_dir or self.home / ".local/state/download-monitor")
        self.databases = []
        self.last_discovery = 0
        self.browser_cache = {}
        self.observed = {}
        self.samples = {}
        self.zip_cache = {}
        self.last_saved = ""
        self.sources = []
        self.writer_pids = set()
        self.last_full_proc = 0
        self._load()

    def _downloads_directory(self):
        path = self.home / ".config/user-dirs.dirs"
        try:
            for line in path.read_text().splitlines():
                if line.startswith('XDG_DOWNLOAD_DIR="') and line.endswith('"'):
                    value = line.split('=', 1)[1][1:-1].replace("$HOME", str(self.home))
                    if value.startswith('/') and '$' not in value:
                        return value
        except OSError:
            pass
        return self.home / "Downloads"

    def _load(self):
        try:
            for row in json.loads((self.state_dir / "observed.json").read_text())[:500]:
                item = Download(**row)
                if item.status in ("running", "paused"):
                    item.status = "unknown"
                    item.detail = "Previously observed transfer; checking for a current writer."
                self.observed[item.path] = item
        except (OSError, ValueError, TypeError):
            pass

    def _save(self):
        rows = sorted(self.observed.values(), key=lambda x: x.updated, reverse=True)[:500]
        data = json.dumps([dataclasses.asdict(x) for x in rows], ensure_ascii=False)
        if data == self.last_saved:
            return
        self.state_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        temp = self.state_dir / "observed.json.tmp"
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w') as stream:
            stream.write(data)
        temp.replace(self.state_dir / "observed.json")
        self.last_saved = data

    def discover(self):
        self.databases = []
        locations = {
            "Chromium": ".config/chromium", "Chrome": ".config/google-chrome",
            "Brave": ".config/BraveSoftware/Brave-Browser", "Edge": ".config/microsoft-edge",
            "Codex": ".config/Codex", "ChatGPT / Codex browser": ".config/ChatGPT",
        }
        seen = set()
        for name, root in locations.items():
            for pattern in ("History", "*/History", "*/*/History", "*/*/*/History"):
                for path in (self.home / root).glob(pattern):
                    if path in seen:
                        continue
                    seen.add(path)
                    self.databases.append((name, path))
        self.last_discovery = time.monotonic()

    def writers(self, browser_paths):
        result = {}
        known = {"curl", "wget", "wget2", "aria2c"}
        downloads_prefix = str(self.downloads).rstrip('/') + '/'
        full_scan = time.monotonic() - self.last_full_proc >= 15
        if full_scan:
            self.last_full_proc = time.monotonic()
        failures = 0
        for directory in self.proc.glob("[0-9]*"):
            try:
                if directory.stat().st_uid != os.getuid():
                    continue
                name = (directory / "comm").read_text().strip()
                if int(directory.name) == os.getpid():
                    continue
                if not full_scan and name not in known and directory.name not in self.writer_pids:
                    continue
                data = (directory / "status").read_text()
                state = next(line.split()[1] for line in data.splitlines() if line.startswith("State:"))
                # No cmdline, environment, socket payload, or downloader log access.
                for fd in (directory / "fd").iterdir():
                    try:
                        path = os.readlink(fd)
                        if not path.startswith('/') or path.endswith(' (deleted)'):
                            continue
                        if name not in known and not path.startswith(downloads_prefix) and path not in browser_paths and path not in self.observed:
                            continue
                        st = fd.stat()
                        if not stat.S_ISREG(st.st_mode):
                            continue
                        info = (directory / "fdinfo" / fd.name).read_text()
                        flags = int(next(x.split()[1] for x in info.splitlines() if x.startswith('flags:')), 8)
                        if flags & os.O_ACCMODE == os.O_RDONLY:
                            continue
                        if name in known and fd.name == "2":
                            continue  # stderr is a log, never a download output
                        result.setdefault(path, []).append({"pid": int(directory.name), "name": name, "paused": state in ('T', 't'), "size": st.st_size, "mtime": st.st_mtime})
                    except (OSError, ValueError, StopIteration):
                        continue
            except PermissionError:
                failures += 1
            except (OSError, ValueError, StopIteration):
                continue
        self.writer_pids = {str(writer['pid']) for group in result.values() for writer in group}
        return result, failures

    def growth(self, key, received):
        now = time.monotonic()
        previous = self.samples.get(key)
        self.samples[key] = (now, received)
        if previous and received is not None and previous[1] is not None:
            delta = received - previous[1]
            elapsed = now - previous[0]
            if delta > 0 and .5 <= elapsed <= 10:
                return True, delta / elapsed
        return False, None

    def poll(self):
        if time.monotonic() - self.last_discovery > 30:
            self.discover()
        items = []
        self.sources = []
        browser_paths = set()
        for name, path in self.databases:
            try:
                key = stamp(path)
                cache = self.browser_cache.get(str(path))
                if cache and cache[0] == key:
                    rows = cache[1]
                else:
                    rows = download_rows(path)
                    self.browser_cache[str(path)] = (key, rows)
                self.sources.append(f"{name} · {path.parent.relative_to(self.home)} · {len(rows)} records")
                for row in rows:
                    current = row['current_path'] or row['target_path']
                    target = row['target_path'] or current
                    browser_paths.update(x for x in [current, target] if x)
                    item_id = f"browser:{path}:{row['id']}"
                    received = max(0, row['received_bytes'])
                    total = row['total_bytes'] if row['total_bytes'] > 0 else None
                    growing, _ = self.growth(item_id, received)
                    status, detail = browser_status(row['state'], row['paused'], growing)
                    if row['state'] == 3:
                        detail += f" Reason code {row['interrupt_reason']}."
                    if current and not Path(current).exists() and not (target and Path(target).exists()):
                        detail += " File is not present at its recorded location."
                    if row['state'] == 0:
                        detail += " Browser counters can update with a delay."
                    items.append(Download(item_id, Path(target).name if target else 'Browser download · no saved filename', current or target, name, status, received, total, detail, row['start_time'] / 1e6 - 11644473600))
            except (OSError, sqlite3.Error, ValueError):
                self.sources.append(f"{name} · {path.parent.relative_to(self.home)} · unavailable this refresh (busy or unreadable)")
                # A stale live record must not keep claiming it is running.
                for row in self.browser_cache.get(str(path), (None, []))[1]:
                    p = row['current_path'] or row['target_path']
                    browser_paths.add(p)
                    items.append(Download(f"browser:{path}:{row['id']}", Path(p).name or 'Browser download', p, name, 'unknown', max(0, row['received_bytes']), row['total_bytes'] if row['total_bytes'] > 0 else None, 'Last browser observation; source unavailable this refresh.'))

        writers, inaccessible = self.writers(browser_paths)
        self.sources.append(f"Terminal tools · curl, wget, wget2, aria2c · {len(writers)} files with an observed writer")
        if inaccessible:
            self.sources.append(f"Process access · {inaccessible} same-user process entries inaccessible")
        for item in items:
            active = writers.get(item.path, [])
            if active and item.status == 'unknown':
                if all(x['paused'] for x in active):
                    item.status = 'paused'
                    item.detail = 'All observed writer processes are suspended by the operating system.'
                else:
                    try:
                        growing, _ = self.growth('file:' + item.path, Path(item.path).stat().st_size)
                    except OSError:
                        growing = False
                    if growing:
                        item.status = 'running'
                        item.detail = 'Output file is growing. Received / total values come from browser history and may lag.'

        files = {}
        try:
            for p in self.downloads.iterdir():
                if p.is_file() and not p.is_symlink() and len(files) < 500:
                    files[str(p)] = p
            self.sources.append(f"Downloads folder · {self.downloads} · {len(files)} files (up to 500, top level)")
        except OSError:
            self.sources.append('Downloads folder · unavailable')
        for path in set(writers) | set(self.observed):
            if Path(path).is_file():
                files[path] = Path(path)
        for path, p in files.items():
            if path in browser_paths:
                continue
            try:
                st = p.stat()
            except OSError:
                continue
            active = writers.get(path, [])
            previous = self.observed.get(path)
            growing, speed = self.growth('file:' + path, st.st_size)
            source = ', '.join(sorted({x['name'] for x in active})) if active else (previous.source if previous else 'Downloads folder')
            state, detail = 'unknown', 'File on disk. No transfer status or total size is available.'
            received = st.st_size
            if active:
                if all(x['paused'] for x in active):
                    state, detail = 'paused', 'All observed writer processes are suspended by the operating system.'
                elif growing:
                    state, detail = 'running', 'Output file is growing. Size and rate describe the file on disk.'
                elif any(x['name'] in ('curl', 'wget', 'wget2', 'aria2c') for x in active):
                    state, detail = 'running', 'Downloader holds this output file open; waiting for more observed bytes.'
                else:
                    detail = 'A process has this file open for writing; no growth observed this interval.'
                detail += ' Writer: ' + ', '.join(f"{x['name']} (PID {x['pid']})" for x in active) + '.'
                if any(x['name'] == 'aria2c' for x in active):
                    received = None
                    speed = None
                    detail += f' Allocated file size {size(st.st_size)}; aria2 may preallocate, so received bytes are unknown.'
            elif growing:
                state, detail = 'running', 'File is growing; the transfer source is unknown.'
            elif p.suffix.lower() in ('.crdownload', '.part', '.partial'):
                state, detail = 'interrupted', 'Partial download file with no observed writer. Why it stopped is unknown.'
            elif p.suffix.lower() == '.zip':
                key = (path, st.st_size, st.st_mtime_ns)
                if key not in self.zip_cache:
                    self.zip_cache[key] = zip_end_present(p)
                if self.zip_cache[key] is False:
                    state, detail = 'incomplete', 'ZIP end directory is missing: incomplete or damaged archive. No active writer was observed; the stopping reason and total are unknown.'
                else:
                    detail = 'ZIP end directory is present. Transfer completion and archive contents have not been verified.'
            elif previous and previous.source != 'Downloads folder':
                detail = 'Previously observed writer is no longer attached. Exit status and completion are unknown.'
            if not active and st.st_mtime:
                detail += ' Last file change: ' + time.strftime('%d %b %Y, %H:%M UTC', time.gmtime(st.st_mtime)) + '.'
            item = Download('file:' + path, p.name, path, source, state, received, None, detail, st.st_mtime, 'on disk', speed if growing and state == 'running' else None)
            items.append(item)
            if active or previous:
                self.observed[path] = dataclasses.replace(item, speed=None)
        self.observed = {p: v for p, v in self.observed.items() if Path(p).exists()}
        try:
            self._save()
        except OSError:
            self.sources.append('Observation history · could not save; live monitoring still works')
        try:
            queue = queued_downloads(self.state_dir / 'queue.json', items, writers)
            items.extend(queue)
            if queue:
                self.sources.append(f'Saved queue · {len(queue)} requests · no automatic transfers; official download setup required')
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            self.sources.append('Saved queue · could not read entries; no transfers will be started')
        order = {'running': 0, 'paused': 1, 'queued': 1.5, 'setup_required': 1.5, 'incomplete': 2, 'interrupted': 3, 'failed': 4, 'unknown': 5, 'completed': 6, 'cancelled': 7}
        items.sort(key=lambda x: (order.get(x.status, 5), -x.updated, x.name))
        return items, list(self.sources)


if __name__ == '__main__':
    rows, sources = Monitor().poll()
    print(json.dumps({'downloads': [dataclasses.asdict(x) for x in rows], 'sources': sources}, indent=2))

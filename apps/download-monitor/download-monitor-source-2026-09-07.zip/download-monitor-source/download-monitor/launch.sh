#!/usr/bin/env bash
set -euo pipefail
DOWNLOAD_MONITOR_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if [[ -n "${WAYLAND_DISPLAY:-}" ]]; then
  export GDK_BACKEND=wayland
  unset GDK_SCALE GDK_DPI_SCALE
fi
exec /usr/bin/python3 "$DOWNLOAD_MONITOR_DIR/app.py" "$@"

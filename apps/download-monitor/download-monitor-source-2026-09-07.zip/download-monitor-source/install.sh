#!/usr/bin/env bash
set -euo pipefail
DOWNLOAD_MONITOR_SOURCE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DOWNLOAD_MONITOR_INSTALL="$HOME/.local/share/download-monitor"
/usr/bin/python3 - <<'PY'
import gi
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw
PY
mkdir -p "$DOWNLOAD_MONITOR_INSTALL" "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/scalable/apps"
for DOWNLOAD_MONITOR_FILE in app.py monitor.py launch.sh icon.svg; do
    install -m 644 "$DOWNLOAD_MONITOR_SOURCE/download-monitor/$DOWNLOAD_MONITOR_FILE" "$DOWNLOAD_MONITOR_INSTALL/$DOWNLOAD_MONITOR_FILE"
done
chmod 755 "$DOWNLOAD_MONITOR_INSTALL/launch.sh"
install -m 644 "$DOWNLOAD_MONITOR_SOURCE/download-monitor/icon.svg" "$HOME/.local/share/icons/hicolor/scalable/apps/local.download.Monitor.svg"
cat > "$HOME/.local/share/applications/local.download.Monitor.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Download Monitor
Comment=View local download activity
Exec="$DOWNLOAD_MONITOR_INSTALL/launch.sh"
Icon=local.download.Monitor
Terminal=false
Categories=Utility;Network;
StartupNotify=true
EOF
if command -v update-desktop-database >/dev/null; then update-desktop-database "$HOME/.local/share/applications"; fi
printf 'Installed Download Monitor: %s\n' "$DOWNLOAD_MONITOR_INSTALL/launch.sh"

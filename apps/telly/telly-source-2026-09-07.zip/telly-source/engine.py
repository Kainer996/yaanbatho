"""Chrome controller. Cookies/passwords stay entirely in Chrome's private profile."""
import json,os,time
from pathlib import Path
from PySide6.QtCore import QObject,QProcess,QProcessEnvironment,QTimer,Signal

CONTROLS_SCRIPT='''if(!globalThis.__tellyKeys){globalThis.__tellyKeys=true;addEventListener('keydown',e=>{if(e.key==='F11'){e.preventDefault();tellyShortcut('fullscreen');}else if(e.key==='Escape'){e.preventDefault();tellyShortcut('escape');}},true);document.addEventListener('fullscreenchange',()=>tellyShortcut(document.fullscreenElement?'player-enter':'player-exit'));}'''

class Browser(QObject):
    started=Signal(int)
    ready=Signal()
    stopped=Signal()
    failed=Signal(str)
    navigated=Signal(str)
    loaded=Signal()
    shortcut=Signal(str)
    def __init__(self,binary,profile,parent=None,scale=None):
        super().__init__(parent)
        self.binary=binary;self.profile=profile;self.session=None;self.target=None
        self.sequence=0;self.pending={};self.buffer=b'';self.closed=False;self.pid=None;self.popups=set()
        self.process=QProcess(self)
        if scale:
            environment=QProcessEnvironment.systemEnvironment();environment.insert('TELLY_SCALE',str(scale));self.process.setProcessEnvironment(environment)
        self.process.readyReadStandardOutput.connect(self.read)
        self.process.errorOccurred.connect(lambda _:self.failed.emit('Chrome could not start. Check the installed browser.'))
        self.process.finished.connect(self.finished)
        self.expiry=QTimer(self);self.expiry.timeout.connect(self.expire);self.expiry.start(1000)
    def start(self):
        Path(self.profile).mkdir(parents=True,exist_ok=True,mode=0o700)
        os.chmod(self.profile,0o700)
        node=os.environ.get('TELLY_NODE','node')
        self.process.start(node,[str(Path(__file__).with_name('browser.mjs')),self.binary,self.profile])
    def call(self,method,params=None,callback=None,session=False):
        if self.closed:return
        self.sequence+=1
        packet={'id':self.sequence,'method':method,'params':params or {}}
        if session:
            if not self.session:return
            packet['sessionId']=self.session if session is True else session
        if callback:self.pending[self.sequence]=(time.monotonic()+25,callback)
        self.process.write((json.dumps(packet)+'\n').encode())
        return self.sequence
    def read(self):
        self.buffer+=bytes(self.process.readAllStandardOutput())
        while b'\n' in self.buffer:
            line,self.buffer=self.buffer.split(b'\n',1)
            try:p=json.loads(line)
            except ValueError:continue
            if p.get('id') in self.pending:
                _,cb=self.pending.pop(p['id']);cb(p)
            method=p.get('method');params=p.get('params',{})
            if method=='Telly.browserStarted':
                self.pid=params['pid'];self.started.emit(self.pid);self.call('Target.getTargets',callback=self.targets)
            elif method=='Telly.browserError':self.failed.emit(params['message'])
            elif method=='Page.frameNavigated' and not params.get('frame',{}).get('parentId'):
                self.navigated.emit(params['frame'].get('url',''))
            elif method=='Page.loadEventFired':self.loaded.emit()
            elif method=='Runtime.bindingCalled' and params.get('name')=='tellyShortcut':
                if params.get('payload') in ('fullscreen','escape','player-enter','player-exit'):
                    self.shortcut.emit(params['payload'])
            elif method=='Target.attachedToTarget' and params.get('targetInfo',{}).get('type')=='iframe':
                self.configure_controls(params['sessionId'])
            elif method=='Target.targetCreated':
                # Keep a single top-level viewing surface. Follow ordinary provider popups
                # in that same surface rather than leaving another page able to play audio.
                info=params['targetInfo']
                if info['type']=='page' and info['targetId']!=self.target:
                    url=info.get('url','')
                    self.popups.add(info['targetId'])
                    if url.startswith('https://'):self.route_popup(info)
                    else:QTimer.singleShot(5000,lambda target=info['targetId']:self.close_popup(target))
            elif method=='Target.targetInfoChanged' and params['targetInfo']['targetId'] in self.popups:
                if params['targetInfo'].get('url','').startswith('https://'):self.route_popup(params['targetInfo'])
    def route_popup(self,info):
        self.navigate(info['url']);self.close_popup(info['targetId'])
    def close_popup(self,target):
        if target in self.popups:self.popups.discard(target);self.call('Target.closeTarget',{'targetId':target})
    def finished(self,*_):
        self.closed=True;self.session=None;self.pending.clear();self.expiry.stop();self.stopped.emit()
    def targets(self,p):
        if self.closed:return
        pages=[x for x in p.get('result',{}).get('targetInfos',[]) if x['type']=='page']
        if not pages:
            QTimer.singleShot(200,lambda:self.call('Target.getTargets',callback=self.targets));return
        self.target=pages[0]['targetId']
        self.call('Target.attachToTarget',{'targetId':self.target,'flatten':True},self.attached)
    def attached(self,p):
        self.session=p.get('result',{}).get('sessionId')
        if not self.session:self.failed.emit('Could not connect the viewing screen.');return
        self.call('Page.enable',session=True)
        self.call('Runtime.enable',session=True)
        self.configure_controls(self.session)
        self.call('Target.setDiscoverTargets',{'discover':True})
        self.ready.emit()
    def configure_controls(self,session):
        self.call('Page.enable',session=session)
        self.call('Runtime.enable',session=session)
        self.call('Runtime.addBinding',{'name':'tellyShortcut','executionContextName':'TellyControls'},session=session)
        self.call('Page.addScriptToEvaluateOnNewDocument',{'worldName':'TellyControls','source':CONTROLS_SCRIPT,'runImmediately':True},session=session)
        self.call('Target.setAutoAttach',{'autoAttach':True,'waitForDebuggerOnStart':False,'flatten':True,'filter':[{'type':'iframe','exclude':False},{'exclude':True}]},session=session)
    def navigate(self,url,callback=None):
        # about:blank commits first: destroys the old document and its audio graph,
        # including cross-origin player frames, before the next channel can start.
        self.call('Page.navigate',{'url':url},callback,session=True)
    def evaluate(self,expression,callback=None):
        return self.call('Runtime.evaluate',{'expression':expression,'returnByValue':True,'awaitPromise':True},callback,session=True)
    def expire(self):
        now=time.monotonic()
        for key in list(self.pending):
            if self.pending[key][0]<now:
                _,cb=self.pending.pop(key);cb({'error':{'message':'Browser response timed out'}})
    def close(self):
        if self.closed:return
        self.call('Browser.close');self.closed=True
        self.process.waitForFinished(2500)
        if self.process.state()!=QProcess.NotRunning:
            self.process.terminate();self.process.waitForFinished(1500)
        if self.process.state()!=QProcess.NotRunning:
            if self.pid:
                try:os.kill(self.pid,9)
                except ProcessLookupError:pass
            self.process.kill();self.process.waitForFinished(1000)
        self.expiry.stop();self.pending.clear()

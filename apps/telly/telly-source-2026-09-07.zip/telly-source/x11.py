"""Find only our Chrome process window, for Qt's supported foreign-window container."""
import ctypes as C
from ctypes.util import find_library

class XWindows:
    def __init__(self):
        self.x = C.CDLL(find_library('X11'))
        self.x.XOpenDisplay.argtypes=[C.c_char_p];self.x.XOpenDisplay.restype=C.c_void_p
        self.x.XDefaultRootWindow.argtypes=[C.c_void_p];self.x.XDefaultRootWindow.restype=C.c_ulong
        self.x.XInternAtom.argtypes=[C.c_void_p,C.c_char_p,C.c_int];self.x.XInternAtom.restype=C.c_ulong
        self.x.XGetWindowProperty.argtypes=[C.c_void_p,C.c_ulong,C.c_ulong,C.c_long,C.c_long,C.c_int,C.c_ulong,C.POINTER(C.c_ulong),C.POINTER(C.c_int),C.POINTER(C.c_ulong),C.POINTER(C.c_ulong),C.POINTER(C.POINTER(C.c_ubyte))]
        self.x.XQueryTree.argtypes=[C.c_void_p,C.c_ulong,C.POINTER(C.c_ulong),C.POINTER(C.c_ulong),C.POINTER(C.POINTER(C.c_ulong)),C.POINTER(C.c_uint)]
        self.x.XGetGeometry.argtypes=[C.c_void_p,C.c_ulong,C.POINTER(C.c_ulong),C.POINTER(C.c_int),C.POINTER(C.c_int),C.POINTER(C.c_uint),C.POINTER(C.c_uint),C.POINTER(C.c_uint),C.POINTER(C.c_uint)]
        self.x.XFree.argtypes=[C.c_void_p]
        self.x.XCloseDisplay.argtypes=[C.c_void_p]
        self.display=self.x.XOpenDisplay(None)
        if not self.display: raise RuntimeError('XWayland is required to display Chrome inside Telly.')
        self.root=self.x.XDefaultRootWindow(self.display)
        self.pid_atom=self.x.XInternAtom(self.display,b'_NET_WM_PID',False)
    def children(self, window):
        root=C.c_ulong();parent=C.c_ulong();items=C.POINTER(C.c_ulong)();n=C.c_uint()
        self.x.XQueryTree(self.display,window,C.byref(root),C.byref(parent),C.byref(items),C.byref(n))
        result=[items[i] for i in range(n.value)] if items else []
        if items:self.x.XFree(items)
        return result
    def pid(self, window):
        actual=C.c_ulong();fmt=C.c_int();n=C.c_ulong();after=C.c_ulong();data=C.POINTER(C.c_ubyte)()
        status=self.x.XGetWindowProperty(self.display,window,self.pid_atom,0,1,False,6,C.byref(actual),C.byref(fmt),C.byref(n),C.byref(after),C.byref(data))
        value=C.cast(data,C.POINTER(C.c_ulong))[0] if status==0 and n.value and fmt.value==32 else None
        if data:self.x.XFree(data)
        return value
    def find(self,pid):
        candidates=[]
        for window in self.children(self.root):
            if self.pid(window)!=pid:continue
            root=C.c_ulong();x=C.c_int();y=C.c_int();width=C.c_uint();height=C.c_uint();border=C.c_uint();depth=C.c_uint()
            self.x.XGetGeometry(self.display,window,C.byref(root),C.byref(x),C.byref(y),C.byref(width),C.byref(height),C.byref(border),C.byref(depth))
            # Chrome also owns tiny hidden leader/utility windows. Those are not
            # the viewing surface and must never be mistaken for the app window.
            if width.value>=200 and height.value>=150:candidates.append((width.value*height.value,window))
        return max(candidates)[1] if candidates else None
    def close(self):
        if self.display:self.x.XCloseDisplay(self.display);self.display=None

#!/usr/bin/env bash
set -euo pipefail
TELLY_SOURCE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TELLY_INSTALL="$HOME/.local/share/telly"
TELLY_CHROME_SOURCE="${1:-}"
/usr/bin/python3 -c 'from PySide6 import QtWidgets, QtNetwork'
command -v node >/dev/null
mkdir -p "$TELLY_INSTALL" "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/scalable/apps"
for TELLY_FILE in app.py ui.py engine.py x11.py browser.mjs start.html channels.json icon.svg launch.sh update-browser.sh; do
  install -m 644 "$TELLY_SOURCE/$TELLY_FILE" "$TELLY_INSTALL/$TELLY_FILE"
done
chmod 755 "$TELLY_INSTALL/launch.sh" "$TELLY_INSTALL/update-browser.sh"
if [[ -n "$TELLY_CHROME_SOURCE" ]]; then
  test -x "$TELLY_CHROME_SOURCE/chrome"
  mkdir -p "$TELLY_INSTALL/runtime"
  cp -a "$TELLY_CHROME_SOURCE/." "$TELLY_INSTALL/runtime/"
elif ! command -v google-chrome-stable >/dev/null && ! command -v google-chrome >/dev/null && [[ ! -x "$TELLY_INSTALL/runtime/chrome" ]]; then
  "$TELLY_INSTALL/update-browser.sh"
fi
install -m 644 "$TELLY_SOURCE/icon.svg" "$HOME/.local/share/icons/hicolor/scalable/apps/telly.svg"
cat > "$HOME/.local/share/applications/telly.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Telly
Comment=British live television in a classic TV
Exec="$TELLY_INSTALL/launch.sh"
Icon=telly
Terminal=false
Categories=AudioVideo;Video;TV;
StartupWMClass=telly
EOF
if command -v update-desktop-database >/dev/null; then update-desktop-database "$HOME/.local/share/applications"; fi
printf 'Installed Telly: %s\n' "$TELLY_INSTALL/launch.sh"

#!/usr/bin/env bash
set -euo pipefail
TELLY_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
if ! command -v node >/dev/null 2>&1; then
  if command -v mise >/dev/null 2>&1; then export TELLY_NODE="$(mise which node)"; fi
fi
exec /usr/bin/python3 "$TELLY_DIR/app.py" "$@"

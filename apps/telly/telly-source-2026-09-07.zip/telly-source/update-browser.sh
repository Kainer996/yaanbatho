#!/usr/bin/env bash
# Keep the genuine Google runtime current without changing the system browser.
set -euo pipefail
TELLY_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TELLY_CONFIG_DIR="${XDG_CONFIG_HOME:-$HOME/.config}/telly"
if [[ -e "$TELLY_CONFIG_DIR/instance.lock" ]]; then
  printf 'Close Telly before updating its browser.\n' >&2; exit 1
fi
TELLY_TEMP="$(mktemp -d)"
trap 'rm -rf -- "$TELLY_TEMP"' EXIT
curl --fail --location --proto '=https' --tlsv1.2 https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb --output "$TELLY_TEMP/chrome.deb"
ar x "$TELLY_TEMP/chrome.deb" --output "$TELLY_TEMP"
tar -xf "$TELLY_TEMP/data.tar.xz" -C "$TELLY_TEMP"
"$TELLY_TEMP/opt/google/chrome/chrome" --version
mkdir -p "$TELLY_DIR/runtime"
cp -a "$TELLY_TEMP/opt/google/chrome/." "$TELLY_DIR/runtime/"
printf 'Telly’s Chrome runtime has been updated.\n'

// Private, inherited pipes only. No debugging TCP port, cookie APIs or network interception.
import {spawn} from 'node:child_process';
import readline from 'node:readline';
const [binary, profile] = process.argv.slice(2);
const browser = spawn(binary, [
  `--user-data-dir=${profile}`, '--remote-debugging-pipe', '--ozone-platform=x11',
  '--class=TellyPlayer', '--no-first-run', '--no-default-browser-check',
  '--disable-session-crashed-bubble', '--app='+new URL('./start.html',import.meta.url).href, '--window-size=1000,700',
  ...(process.env.TELLY_SCALE ? ['--force-device-scale-factor='+process.env.TELLY_SCALE] : []),
], {stdio:['ignore','ignore','ignore','pipe','pipe']});
const out = value => process.stdout.write(JSON.stringify(value)+'\n');
browser.on('spawn',()=>out({method:'Telly.browserStarted',params:{pid:browser.pid}}));
browser.on('error',()=>out({method:'Telly.browserError',params:{message:'Could not start Chrome.'}}));
browser.on('exit',code=>{out({method:'Telly.browserExited',params:{code}});process.exit(code || 0);});
let buffer='';
browser.stdio[4].on('data', data=>{
  buffer+=data.toString();
  let i;
  while((i=buffer.indexOf('\0'))>=0){
    const packet=buffer.slice(0,i);buffer=buffer.slice(i+1);
    if(packet) process.stdout.write(packet+'\n');
  }
});
readline.createInterface({input:process.stdin}).on('line',line=>{
  try{JSON.parse(line);browser.stdio[3].write(line+'\0');}catch{}
}).on('close',()=>browser.kill('SIGTERM'));
process.on('SIGTERM',()=>browser.kill('SIGTERM'));
process.on('SIGINT',()=>browser.kill('SIGTERM'));

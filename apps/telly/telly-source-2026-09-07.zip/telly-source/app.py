#!/usr/bin/env python3
"""Telly: native classic TV with an unmodified, genuine Chrome viewing surface."""
import json,os,shutil,sys,time,subprocess
from pathlib import Path
from urllib.parse import urlparse
os.environ['QT_QPA_PLATFORM']='xcb'
from PySide6.QtCore import Qt,QTimer,QLockFile,QSaveFile,QIODevice,QProcess
from PySide6.QtGui import QWindow,QIcon,QShortcut,QKeySequence
from PySide6.QtWidgets import QApplication,QWidget,QMessageBox
from PySide6.QtNetwork import QLocalServer,QLocalSocket
from ui import Television
from engine import Browser
from x11 import XWindows

ROOT=Path(__file__).resolve().parent
CHANNELS=json.loads((ROOT/'channels.json').read_text())
CONFIG=Path(os.environ.get('TELLY_CONFIG',str(Path(os.environ.get('XDG_CONFIG_HOME',str(Path.home()/'.config')))/'telly')))

def chrome_path():
    candidates=[os.environ.get('TELLY_CHROME'),shutil.which('google-chrome-stable'),shutil.which('google-chrome'),str(ROOT/'runtime'/'chrome'),str(Path.home()/'.local/share/telly/runtime/chrome')]
    return next((p for p in candidates if p and os.access(p,os.X_OK)),None)

class Telly(Television):
    def __init__(self,config=CONFIG,binary=None):
        super().__init__(CHANNELS)
        self.config=Path(config);self.config.mkdir(parents=True,exist_ok=True,mode=0o700);os.chmod(self.config,0o700)
        self.binary=binary or chrome_path();self.engine=None;self.browser_pid=None;self.container=None;self.foreign=None;self.x=None
        self.selected='bbc-one';self.powered=False;self.serial=0;self.current_url='';self.closing=False;self.explicit_cinema=False;self.is_loading=False;self.signing_in=False;self.login_process=None;self.login_pid=None;self.login_start=None
        try:
            state=json.loads((self.config/'settings.json').read_text())
            if state.get('channel') in self.channels:self.selected=state['channel']
            size=state.get('size',[1000,600]);self.resize(max(800,min(1200,int(size[0]))),max(480,min(760,int(size[1]))))
        except (OSError,ValueError,TypeError,IndexError,AttributeError):pass
        self.setWindowIcon(QIcon(str(ROOT/'icon.svg')))
        self.set_channel(self.selected);self.set_powered(False)
        self.set_status('Choose a channel. Sign in directly with its broadcaster when asked.')
        self.channel_selected.connect(self.tune)
        self.previous_requested.connect(lambda:self.step(-1));self.next_requested.connect(lambda:self.step(1))
        self.power_requested.connect(self.power);self.fullscreen_requested.connect(self.toggle_fullscreen)
        self.reload_requested.connect(self.reload);self.help_requested.connect(self.help)
        self.signin_requested.connect(self.sign_in)
        self.close_requested.connect(self.close)
        self.shortcuts=[]
        for key,fn in [('F11',self.toggle_fullscreen),('Escape',self.escape)]:
            shortcut=QShortcut(QKeySequence(key),self);shortcut.activated.connect(fn);self.shortcuts.append(shortcut)
        self.embed_timer=QTimer(self);self.embed_timer.timeout.connect(self.embed)
        self.loading_timer=QTimer(self);self.loading_timer.setSingleShot(True);self.loading_timer.timeout.connect(self.slow_load)
        self.switch_timer=QTimer(self);self.switch_timer.setSingleShot(True);self.switch_timer.setInterval(120);self.switch_timer.timeout.connect(self.perform_switch)
        self.login_timer=QTimer(self);self.login_timer.timeout.connect(self.poll_sign_in);self.login_timer.setInterval(500)
        self.restore_sign_in()
        self.setObjectName('telly')
        # Clamp restored geometry before the first show, not just after the
        # compositor maps it, so an old oversized setting cannot cover the screen.
        screen=QApplication.primaryScreen()
        if screen:
            available=screen.availableGeometry()
            self.resize(min(self.width(),max(800,int(available.width()*.78))),
                        min(self.height(),max(480,int(available.height()*.78))))
    def save(self):
        size=self.normalGeometry().size() if self.isFullScreen() else self.size()
        content={'channel':self.selected,'size':[size.width(),size.height()]}
        f=QSaveFile(str(self.config/'settings.json'))
        if f.open(QIODevice.OpenModeFlag.WriteOnly):f.write(json.dumps(content).encode());f.commit()
    def start_browser(self):
        if not self.binary:
            self.error('Chrome is missing. Run the installer, then select a channel again.');return
        try:self.x=XWindows()
        except RuntimeError as e:self.error(str(e));return
        self.engine=Browser(self.binary,str(self.config/'profile'),self,scale=self.devicePixelRatioF())
        self.engine.started.connect(self.browser_started)
        self.engine.ready.connect(lambda:self.navigate_selected(self.serial))
        self.engine.failed.connect(self.error);self.engine.stopped.connect(lambda owner=self.engine:self.browser_stopped(owner))
        self.engine.navigated.connect(self.navigation);self.engine.loaded.connect(self.loaded)
        self.engine.shortcut.connect(self.browser_shortcut)
        self.embed_started=time.monotonic();self.embed_timer.start(100);self.engine.start()
    def browser_started(self,pid):self.browser_pid=pid
    def embed(self):
        if self.browser_pid and self.x:
            wid=self.x.find(self.browser_pid)
            if wid:
                self.foreign=QWindow.fromWinId(wid)
                self.container=QWidget.createWindowContainer(self.foreign,self)
                self.container.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
                self.screen_placeholder.hide();self.screen_layout.addWidget(self.container,1)
                self.embed_timer.stop();self.container.show();return
        if time.monotonic()-self.embed_started>18:
            self.embed_timer.stop();self.error('The browser screen could not attach. Press Power, then try again.')
            if self.engine:self.engine.close()
    def tune(self,channel):
        if self.closing or self.signing_in or channel not in self.channels:return
        self.selected=channel;self.serial+=1;generation=self.serial
        self.powered=True;self.set_powered(True);self.set_channel(channel);self.save()
        self.set_status('Tuning to '+self.channels[channel]['name']+'…')
        if not self.engine:self.start_browser()
        elif self.engine.session:
            # Coalesce a quick turn of the dial so competing navigation requests
            # cannot cancel the final choice or resurrect an intermediate channel.
            self.switch_timer.start()
    def perform_switch(self):
        if self.closing or self.signing_in or not self.powered or not self.engine:return
        generation=self.serial
        self.engine.call('Page.stopLoading',session=True)
        self.engine.navigate('about:blank',lambda p:self.after_blank(p,generation))
    def after_blank(self,p,generation):
        if generation!=self.serial or not self.powered:return
        if 'error' in p or p.get('result',{}).get('errorText'):
            self.error('Could not stop the previous page safely. Press Power, then retry.');return
        self.navigate_selected(generation)
    def navigate_selected(self,generation):
        if generation!=self.serial or not self.powered or not self.engine:return
        self.is_loading=True;self.loading_timer.start(22000)
        self.engine.navigate(self.channels[self.selected]['url'],lambda p:self.navigation_result(p,generation))
    def navigation_result(self,p,generation):
        if generation!=self.serial:return
        if 'error' in p or p.get('result',{}).get('errorText'):
            self.error('Could not load the broadcaster. Check your connection and press Reload.')
    def navigation(self,url):
        self.current_url=url
        if url=='about:blank':return
        host=urlparse(url).hostname or ''
        if url.startswith('chrome-error:'):self.error('This page could not load. Check your connection and press Reload.');return
        if host=='accounts.google.com':
            self.set_status('Google sign-in needs normal Chrome. Use the Sign in button on the cabinet.')
        elif any(word in urlparse(url).path.lower() for word in ('signin','sign-in','login','session')):
            self.set_status('Use Sign in on the cabinet to finish securely in normal Chrome.')
        else:self.set_status(host+' · use the official player’s Watch live and fullscreen controls.')
    def loaded(self):
        if self.current_url=='about:blank':return
        self.is_loading=False;self.loading_timer.stop()
    def slow_load(self):
        if self.is_loading:self.set_status('Taking longer than expected. The broadcaster may need sign-in; Reload retries this channel.')
    def step(self,delta):
        ids=list(self.channels);self.tune(ids[(ids.index(self.selected)+delta)%len(ids)])
    def power(self):
        if self.signing_in or self.closing:return
        if not self.powered:self.tune(self.selected);return
        self.powered=False;self.serial+=1;self.loading_timer.stop();self.embed_timer.stop();self.switch_timer.stop()
        engine=self.engine;self.engine=None
        if engine:engine.close();engine.deleteLater()
        self.remove_screen();self.set_powered(False);self.set_status('Standby · sign-ins stay saved in the browser. Select a channel to resume.')
    def remove_screen(self):
        self.browser_pid=None
        if self.container:self.screen_layout.removeWidget(self.container);self.container.deleteLater();self.container=None;self.foreign=None
        if self.x:self.x.close();self.x=None
        self.screen_placeholder.show()
    def browser_stopped(self,owner):
        if self.closing:return
        if self.engine is owner:
            self.engine.deleteLater();self.engine=None;self.powered=False;self.set_powered(False)
            self.set_status('The viewing screen closed. Select a channel to reopen it.');self.remove_screen()
    def error(self,message):
        self.is_loading=False;self.loading_timer.stop();self.set_status(message)
    def reload(self):
        self.tune(self.selected)
    def sign_in(self):
        if self.signing_in or self.closing:return
        if not self.binary:self.error('Chrome is missing. Run the Telly installer.');return
        if self.powered:self.power()
        self.exit_fullscreen();self.set_signing_in(True)
        self.set_status('Sign in in the normal Chrome window, then close it to return to Telly.')
        # The SAME profile is opened by ordinary Chrome. No debugging, automation,
        # reparenting, data extraction, session imports or token handoff occur.
        try:
            self.login_process=subprocess.Popen([self.binary,
                '--user-data-dir='+str(self.config/'profile'),'--no-first-run',
                '--no-default-browser-check','--disable-background-mode','--ozone-platform=x11','--new-window',
                self.channels[self.selected]['url']],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
            self.login_pid=self.login_process.pid;self.login_start=self.process_start(self.login_pid)
            self.write_signin_marker();self.login_timer.start()
        except OSError:self.sign_in_error(None)
    @staticmethod
    def process_start(pid):
        try:
            stat=(Path('/proc')/str(pid)/'stat').read_text().split(') ',1)[1].split()
            return stat[19] if stat[0]!='Z' else None
        except (OSError,ValueError,IndexError):return None
    def write_signin_marker(self):
        (self.config/'signin-process.json').write_text(json.dumps({'pid':self.login_pid,'start':self.login_start}))
    def restore_sign_in(self):
        try:
            marker=json.loads((self.config/'signin-process.json').read_text())
            if marker.get('start') and self.process_start(int(marker['pid']))==marker['start']:
                self.login_pid=int(marker['pid']);self.login_start=marker['start'];self.set_signing_in(True);self.login_timer.start()
        except (OSError,ValueError,TypeError,KeyError):pass
    def poll_sign_in(self):
        alive=self.login_process.poll() is None if self.login_process else self.login_start and self.process_start(self.login_pid)==self.login_start
        if not alive:self.sign_in_finished()
    def sign_in_error(self,_):
        if self.signing_in:
            self.set_signing_in(False);self.error('Could not open Chrome for sign-in. Please try again.')
    def sign_in_finished(self,*_):
        if not self.signing_in:return
        self.set_signing_in(False)
        self.login_timer.stop();self.login_process=None;self.login_pid=None;self.login_start=None
        (self.config/'signin-process.json').unlink(missing_ok=True)
        # Return only once on normal browser closure. Failed sign-in is never
        # auto-retried in a loop: another external attempt needs an explicit click.
        if not self.closing:self.focus_existing();self.tune(self.selected)
    def toggle_fullscreen(self):
        if self.signing_in or self.closing:return
        if self.isFullScreen():self.exit_fullscreen()
        else:
            self.explicit_cinema=True;self.set_cinema(True);self.showFullScreen()
    def exit_fullscreen(self):
        if self.isFullScreen():self.explicit_cinema=False;self.set_cinema(False);self.showNormal()
    def escape(self):
        if self.isFullScreen():self.exit_fullscreen()
        else:self.close()
    def browser_shortcut(self,key):
        if key=='fullscreen':self.toggle_fullscreen()
        elif key=='escape':self.escape()
        elif key=='player-enter' and not self.isFullScreen():
            self.explicit_cinema=False;self.set_cinema(True);self.showFullScreen()
        elif key=='player-exit' and not self.explicit_cinema:self.exit_fullscreen()
    def help(self):
        dialog=QMessageBox(self);dialog.setWindowTitle('Using Telly');dialog.setTextFormat(Qt.TextFormat.RichText)
        dialog.setText('<h3>Your channels, in one television.</h3><p>Choose a channel or turn the dial. Use the broadcaster’s own Watch live button, subtitles and volume controls.</p><p>Use <b>Sign in</b> on the cabinet to open normal Chrome. Complete the broadcaster’s sign-in yourself, then close its Chrome windows to return. This also supports the normal Sign in with Google flow. The same private browser profile is used for viewing; cookies are not imported or extracted. Providers may ask you to sign in again.</p><p>Power stops the entire viewing browser. Switching channels unloads the old page first. Fullscreen hides the cabinet; Escape or the exit button brings it back.</p><p>ITVX does not officially list Linux support. Protected playback still depends on the broadcaster, your account, location and programme rights. Any provider declarations must be completed by you.</p><p>To change region or account details, use the official page. Telly does not invent programme listings.</p>')
        dialog.setDetailedText('Browser profile: '+str(self.config/'profile')+'\nBrowser: '+str(self.binary)+'\nUpdate the bundled Chrome periodically by running update-browser.sh from Telly’s install folder.');dialog.exec()
    def focus_existing(self):
        if self.isMinimized():self.showNormal()
        self.show();self.raise_();self.activateWindow()
        if self.windowHandle():self.windowHandle().requestActivate()
        self.hypr_dispatch(f'hl.dsp.focus({{ window = "pid:{os.getpid()}" }})')
    def hypr_dispatch(self,code):
        if os.environ.get('HYPRLAND_INSTANCE_SIGNATURE') and shutil.which('hyprctl'):
            try:subprocess.run(['hyprctl','dispatch',code],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=2)
            except (OSError,subprocess.SubprocessError):pass
    def arrange(self):
        # Own-window placement only; no global rules or desktop settings change.
        selector=f'pid:{os.getpid()}'
        self.hypr_dispatch(f'hl.dsp.window.float({{ window = "{selector}", action = "set" }})')
        if os.environ.get('HYPRLAND_INSTANCE_SIGNATURE') and shutil.which('hyprctl'):
            try:
                monitors=json.loads(subprocess.check_output(['hyprctl','monitors','-j'],timeout=2))
                monitor=next((m for m in monitors if m.get('focused')),monitors[0])
                width=int(monitor['width']/monitor['scale']);height=int(monitor['height']/monitor['scale'])
                target_w=min(1000,int(width*.78));target_h=min(650,int(height*.78))
                self.hypr_dispatch(f'hl.dsp.window.resize({{ window = "{selector}", x = {target_w}, y = {target_h} }})')
                self.hypr_dispatch(f'hl.dsp.window.center({{ window = "{selector}" }})')
            except (OSError,ValueError,KeyError,IndexError,subprocess.SubprocessError):pass
        self.focus_existing()
    def closeEvent(self,event):
        self.closing=True;self.save();self.embed_timer.stop();self.loading_timer.stop();self.switch_timer.stop()
        self.login_timer.stop()
        # A user-operated sign-in window is deliberately independent. Its process
        # and profile survive closing Telly; the next launch can observe it again.
        if self.engine:self.engine.close()
        self.engine=None;self.remove_screen()
        event.accept()
        QTimer.singleShot(0,QApplication.instance().quit)

def main():
    CONFIG.mkdir(parents=True,exist_ok=True,mode=0o700);os.chmod(CONFIG,0o700)
    # XWayland otherwise gives Qt physical pixels while Chrome chooses the
    # desktop scale independently. Use the actual monitor scale for both.
    if 'QT_SCALE_FACTOR' not in os.environ and os.environ.get('HYPRLAND_INSTANCE_SIGNATURE'):
        try:
            monitors=json.loads(subprocess.check_output(['hyprctl','monitors','-j'],timeout=2))
            monitor=next((m for m in monitors if m.get('focused')),monitors[0])
            os.environ['QT_SCALE_FACTOR']=str(monitor['scale'])
        except (OSError,ValueError,KeyError,IndexError,subprocess.SubprocessError):pass
    app=QApplication(['telly']);app.setApplicationName('telly');app.setDesktopFileName('telly')
    socket_name=str(CONFIG/'instance.sock')
    client=QLocalSocket();client.connectToServer(socket_name)
    if client.waitForConnected(600):
        client.write(b'focus\n');client.waitForBytesWritten(600);client.disconnectFromServer();return 0
    lock=QLockFile(str(CONFIG/'instance.lock'));lock.setStaleLockTime(0)
    if not lock.tryLock(200):return 0
    QLocalServer.removeServer(socket_name)
    server=QLocalServer();server.setSocketOptions(QLocalServer.SocketOption.UserAccessOption)
    if not server.listen(socket_name):return 1
    window=Telly();window.show();QTimer.singleShot(100,window.arrange)
    def connected():
        sock=server.nextPendingConnection()
        if sock:
            # This endpoint can only focus the app. It cannot control/read browser data.
            window.focus_existing();sock.disconnectFromServer();sock.deleteLater()
    server.newConnection.connect(connected)
    if '--standby' not in sys.argv:QTimer.singleShot(350,lambda:window.tune(window.selected))
    result=app.exec();server.close();lock.unlock();return result

if __name__=='__main__':sys.exit(main())

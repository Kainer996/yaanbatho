"""Telly's native cabinet and channel controls.

The controller owns playback. Add its browser container to ``screen_layout``
after removing ``screen_placeholder``. This module never touches browser data.
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRect, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPen, QRadialGradient
from PySide6.QtWidgets import (
    QAbstractButton,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)


CREAM = "#f3e4c8"
MUTED = "#baa98c"
SIGNIN_STATUS = "Finish signing in in Chrome, then close its window to return to Telly."


class DragHeader(QWidget):
    """Window-manager move with a manual fallback for undecorated X11 windows.

    Set ``force_manual = True`` to exercise the fallback with QTest/Xvfb.
    Child buttons keep their normal event handling; passive labels are transparent.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.force_manual = False
        self._drag_origin = None
        self.setCursor(Qt.CursorShape.SizeAllCursor)

    def mousePressEvent(self, event):
        window = self.window()
        if event.button() != Qt.MouseButton.LeftButton or window.isFullScreen() or window.isMaximized():
            return super().mousePressEvent(event)
        handle = window.windowHandle()
        if not self.force_manual and handle and handle.startSystemMove():
            event.accept()
            return
        self._drag_origin = event.globalPosition().toPoint()
        self._window_origin = window.pos()
        self.grabMouse()
        event.accept()

    def mouseMoveEvent(self, event):
        if self._drag_origin is not None:
            self.window().move(self._window_origin + event.globalPosition().toPoint() - self._drag_origin)
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and self._drag_origin is not None:
            self._drag_origin = None
            self.releaseMouse()
            event.accept()
        else:
            super().mouseReleaseEvent(event)


class EdgeResizeHandle(QWidget):
    """Cabinet-padding resize target with native and testable manual paths."""

    def __init__(self, edges, parent=None, visible_grip=False):
        super().__init__(parent)
        self.edges = edges
        self.visible_grip = visible_grip
        self.force_manual = False
        self._drag_origin = None
        horizontal = bool(edges & (Qt.Edge.LeftEdge | Qt.Edge.RightEdge))
        vertical = bool(edges & (Qt.Edge.TopEdge | Qt.Edge.BottomEdge))
        if horizontal and vertical:
            diagonal = bool(edges & Qt.Edge.LeftEdge) == bool(edges & Qt.Edge.TopEdge)
            cursor = Qt.CursorShape.SizeFDiagCursor if diagonal else Qt.CursorShape.SizeBDiagCursor
        else:
            cursor = Qt.CursorShape.SizeHorCursor if horizontal else Qt.CursorShape.SizeVerCursor
        self.setCursor(cursor)
        self.setToolTip("Drag to resize Telly")
        self.setAccessibleName("Resize Telly window")

    def mousePressEvent(self, event):
        window = self.window()
        if event.button() != Qt.MouseButton.LeftButton or window.isFullScreen() or window.isMaximized():
            return super().mousePressEvent(event)
        handle = window.windowHandle()
        if not self.force_manual and handle and handle.startSystemResize(self.edges):
            event.accept()
            return
        self._drag_origin = event.globalPosition().toPoint()
        self._window_geometry = QRect(window.geometry())
        self.grabMouse()
        event.accept()

    def mouseMoveEvent(self, event):
        if self._drag_origin is None:
            return super().mouseMoveEvent(event)
        window = self.window()
        delta = event.globalPosition().toPoint() - self._drag_origin
        rect = QRect(self._window_geometry)
        minimum = window.minimumSize().expandedTo(window.minimumSizeHint())
        maximum = window.maximumSize()
        if self.edges & Qt.Edge.LeftEdge:
            rect.setLeft(max(rect.right() - maximum.width() + 1,
                             min(rect.right() - minimum.width() + 1, rect.left() + delta.x())))
        if self.edges & Qt.Edge.RightEdge:
            rect.setRight(min(rect.left() + maximum.width() - 1,
                              max(rect.left() + minimum.width() - 1, rect.right() + delta.x())))
        if self.edges & Qt.Edge.TopEdge:
            rect.setTop(max(rect.bottom() - maximum.height() + 1,
                            min(rect.bottom() - minimum.height() + 1, rect.top() + delta.y())))
        if self.edges & Qt.Edge.BottomEdge:
            rect.setBottom(min(rect.top() + maximum.height() - 1,
                               max(rect.top() + minimum.height() - 1, rect.bottom() + delta.y())))
        window.setGeometry(rect)
        event.accept()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and self._drag_origin is not None:
            self._drag_origin = None
            self.releaseMouse()
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    def paintEvent(self, event):
        if self.visible_grip:
            painter = QPainter(self)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.setPen(QPen(QColor("#d7b986"), 1.3))
            for length in (4, 8, 12):
                painter.drawLine(self.width() - length - 2, self.height() - 3,
                                 self.width() - 3, self.height() - length - 2)


class Cabinet(QWidget):
    """A restrained walnut case, painted at the actual display resolution."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.cinema = False

    def paintEvent(self, event):
        painter = QPainter(self)
        if self.cinema:
            painter.fillRect(self.rect(), QColor("#090a09"))
            return
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        gradient = QLinearGradient(0, 0, self.width(), self.height())
        gradient.setColorAt(0, QColor("#5f3e29"))
        gradient.setColorAt(0.33, QColor("#38261d"))
        gradient.setColorAt(0.7, QColor("#493021"))
        gradient.setColorAt(1, QColor("#291e18"))
        painter.setPen(QPen(QColor("#806045"), 1))
        painter.setBrush(gradient)
        painter.drawRoundedRect(rect, 17, 17)
        painter.setClipRect(rect.adjusted(2, 2, -2, -2))
        # Deterministic horizontal wood grain; intentionally quiet behind text.
        for row in range(4, self.height(), 5):
            painter.setPen(QPen(QColor(212, 166, 111, 9 + row % 11), 0.65))
            points = [
                QPointF(x, row + math.sin(x / 126 + row / 52) * 2.2)
                for x in range(0, self.width() + 25, 24)
            ]
            for start, end in zip(points, points[1:]):
                painter.drawLine(start, end)
        painter.setClipping(False)
        painter.setPen(QPen(QColor(247, 205, 148, 32), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(rect.adjusted(7, 7, -7, -7), 12, 12)


class ChannelButton(QPushButton):
    def __init__(self, channel: dict, parent=None):
        super().__init__(parent)
        self.setObjectName("channelButton")
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(56)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setAccessibleName(f"Channel {channel['number']}, {channel['name']}, {channel['provider']}")
        self.setToolTip(f"Watch {channel['name']} on {channel['provider']}")
        row = QHBoxLayout(self)
        row.setContentsMargins(11, 7, 11, 7)
        row.setSpacing(11)
        self.number = QLabel(str(channel["number"]).zfill(2))
        self.number.setObjectName("channelNumber")
        self.number.setFixedWidth(25)
        details = QVBoxLayout()
        details.setSpacing(1)
        self.title = QLabel(channel["name"])
        self.title.setObjectName("channelTitle")
        self.provider = QLabel(channel["provider"])
        self.provider.setObjectName("channelProvider")
        details.addWidget(self.title)
        details.addWidget(self.provider)
        row.addWidget(self.number)
        row.addLayout(details, 1)
        self.light = QLabel("●")
        self.light.setObjectName("channelLight")
        self.light.setFixedWidth(11)
        row.addWidget(self.light)
        for label in (self.number, self.title, self.provider, self.light):
            label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.toggled.connect(self._refresh_labels)
        self._refresh_labels(False)

    def _refresh_labels(self, checked):
        self.number.setStyleSheet(f"color: {'#d9ad60' if checked else '#9b9688'}; font: 12px 'DejaVu Sans Mono';")
        self.title.setStyleSheet(f"color: {'#fff1cf' if checked else '#e6dfd1'}; font-size: 13px; font-weight: 600;")
        self.provider.setStyleSheet("color: #a5a092; font-size: 10px;")
        self.light.setStyleSheet(f"color: {'#e9b65e' if checked else '#474940'}; font-size: 9px;")


class TuningDial(QWidget):
    stepped = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.channel_number = "01"
        self.setFixedSize(76, 76)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAccessibleName("Channel dial")
        self.setToolTip("Turn the wheel, click the left or right half, or use arrow keys to change channel")

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.scale(self.width() / 92, self.height() / 92)
        if not self.isEnabled():
            p.setOpacity(0.45)
        centre = QPointF(46, 46)
        p.setPen(QPen(QColor("#151612"), 1))
        p.setBrush(QColor("#0c0e0b"))
        p.drawEllipse(QRectF(3, 4, 86, 86))
        for index in range(36):
            angle = index * math.pi / 18
            p.setPen(QPen(QColor("#746f59"), 1))
            p.drawLine(
                centre + QPointF(math.cos(angle) * 41, math.sin(angle) * 41),
                centre + QPointF(math.cos(angle) * 38.5, math.sin(angle) * 38.5),
            )
        rim = QLinearGradient(0, 5, 80, 90)
        rim.setColorAt(0, QColor("#d2c5a5"))
        rim.setColorAt(0.35, QColor("#6f6e59"))
        rim.setColorAt(0.65, QColor("#363c31"))
        rim.setColorAt(1, QColor("#aaa084"))
        p.setPen(QPen(QColor("#a39879"), 0.7))
        p.setBrush(rim)
        p.drawEllipse(QRectF(11, 11, 70, 70))
        face = QRadialGradient(QPointF(34, 29), 72)
        face.setColorAt(0, QColor("#485044"))
        face.setColorAt(1, QColor("#141a15"))
        p.setPen(QPen(QColor("#10150f"), 1))
        p.setBrush(face)
        p.drawEllipse(QRectF(17, 17, 58, 58))
        p.setPen(QPen(QColor("#ecd49a"), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawLine(QPointF(46, 20), QPointF(46, 28))
        p.setPen(QColor(CREAM))
        p.setFont(QFont("DejaVu Sans Mono", 14, QFont.Weight.Medium))
        p.drawText(QRectF(22, 34, 48, 26), Qt.AlignmentFlag.AlignCenter, self.channel_number)
        if self.hasFocus():
            p.setPen(QPen(QColor("#e7bb70"), 1.5, Qt.PenStyle.DashLine))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(QRectF(1, 1, 90, 90))

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.setFocus()
            self.stepped.emit(-1 if event.position().x() < self.width() / 2 else 1)

    def wheelEvent(self, event):
        if event.angleDelta().y():
            self.stepped.emit(-1 if event.angleDelta().y() > 0 else 1)
            event.accept()

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Left, Qt.Key.Key_Up):
            self.stepped.emit(-1)
        elif event.key() in (Qt.Key.Key_Right, Qt.Key.Key_Down, Qt.Key.Key_Space):
            self.stepped.emit(1)
        else:
            super().keyPressEvent(event)


class ElidedLabel(QLabel):
    """A one-line status display which cannot force the cabinet wider."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.full_text = ""
        self.setMinimumWidth(0)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)

    def setText(self, text):
        self.full_text = text
        self.setToolTip(text)
        self._elide()

    def resizeEvent(self, event):
        self._elide()
        super().resizeEvent(event)

    def _elide(self):
        super().setText(self.fontMetrics().elidedText(self.full_text, Qt.TextElideMode.ElideRight, max(0, self.width())))


class Television(Cabinet):
    channel_selected = Signal(str)
    previous_requested = Signal()
    next_requested = Signal()
    power_requested = Signal()
    fullscreen_requested = Signal()
    reload_requested = Signal()
    help_requested = Signal()
    signin_requested = Signal()
    close_requested = Signal()

    def __init__(self, channels: list[dict], parent=None):
        super().__init__(parent)
        self.channels = {str(channel["id"]): channel for channel in channels}
        self.channel_buttons = {}
        self.current_channel_id = None
        self.powered = True
        self.signing_in = False
        self._status_before_signin = ""
        self.setWindowTitle("Telly — British live television")
        self.setMinimumSize(800, 480)
        self.resize(1000, 600)
        self.setStyleSheet("""
            QWidget { color: #f3e4c8; font-family: 'DejaVu Sans'; font-size: 12px; }
            QLabel { background: transparent; border: none; }
            QFrame#bezel { background: #171b17; border: 1px solid #71634b; border-radius: 14px; }
            QWidget#screen { background: #080a09; border: 1px solid #080a09; border-radius: 5px; }
            QFrame#controlPanel { background: #22281f; border: 1px solid #6b5e45; border-radius: 11px; }
            QScrollArea { background: transparent; border: none; }
            QWidget#channelList { background: transparent; }
            QPushButton { background: #383e31; border: 1px solid #655f49; border-bottom: 3px solid #12190f;
                border-radius: 6px; color: #f0e4cc; padding: 8px 10px; font-weight: 600; }
            QPushButton:hover { background: #48513b; border-color: #b7a47a; }
            QPushButton:pressed { background: #1c2319; border-bottom: 1px solid #736b51; padding-top: 10px; }
            QPushButton:focus { border-color: #eac079; }
            QPushButton:disabled { background: #252c21; border-color: #3c4433; color: #777e6c; }
            QPushButton#channelButton { background: #1c221b; border: 1px solid #3b4333; border-bottom: 2px solid #131911;
                padding: 0; border-radius: 6px; text-align: left; }
            QPushButton#channelButton:hover { background: #303829; border-color: #6e795b; }
            QPushButton#channelButton:checked { background: #353b27; border: 1px solid #a6935e; border-left: 3px solid #e0b267; }
            QPushButton#smallControl { font-size: 11px; padding: 7px 8px; }
            QPushButton#signinButton { font-size: 11px; padding: 7px 8px; background: #605037; border-color: #ab9361; }
            QPushButton#signinButton:hover { background: #776140; }
            QPushButton#signinButton:disabled { background: #302e22; border-color: #4c4a37; color: #817b66; }
            QPushButton#powerButton { background: #413627; border-color: #817153; }
            QPushButton#powerButton:hover { background: #59452d; }
            QPushButton#closeButton { background: #392d24; color: #f4dec1; border: 1px solid #ad8460;
                border-radius: 5px; padding: 0; font-size: 23px; font-weight: 400; }
            QPushButton#closeButton:hover { background: #88452f; border-color: #e3b38a; }
            QScrollBar:vertical { background: #1a2118; width: 6px; border-radius: 3px; margin: 2px 0; }
            QScrollBar::handle:vertical { background: #6f745c; border-radius: 3px; min-height: 24px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
        """)

        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(18, 12, 18, 12)
        self.main_layout.setSpacing(9)
        self.header = DragHeader()
        self.header.setObjectName("titleBar")
        header_layout = QHBoxLayout(self.header)
        header_layout.setContentsMargins(5, 0, 5, 0)
        header_layout.setSpacing(12)
        brand = QLabel("telly")
        brand.setStyleSheet("font-family: 'DejaVu Serif'; font-style: italic; font-size: 28px; font-weight: 600; color: #f5e2bb;")
        strapline = QLabel("BRITISH LIVE TELEVISION")
        strapline.setStyleSheet("font-size: 10px; color: #c3ae8c; letter-spacing: 2px;")
        header_layout.addWidget(brand)
        header_notes = QVBoxLayout()
        header_notes.setSpacing(2)
        header_notes.addWidget(strapline)
        self.move_hint = QLabel("Esc to close · drag here to move")
        self.move_hint.setStyleSheet("font-size: 10px; color: #dbc7a4;")
        header_notes.addWidget(self.move_hint)
        header_layout.addLayout(header_notes)
        header_layout.addStretch(1)
        self.station_display = QLabel("READY TO TUNE IN")
        self.station_display.setStyleSheet("font-family: 'DejaVu Sans Mono'; font-size: 11px; color: #dfcfad; letter-spacing: 1px;")
        header_layout.addWidget(self.station_display)
        self.close_button = QPushButton("×")
        self.close_button.setObjectName("closeButton")
        self.close_button.setFixedSize(34, 32)
        self.close_button.setAccessibleName("Close Telly")
        self.close_button.setToolTip("Close Telly · Esc")
        self.close_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.close_button.clicked.connect(self.close_requested)
        header_layout.addWidget(self.close_button)
        for passive in (brand, strapline, self.move_hint, self.station_display):
            passive.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.main_layout.addWidget(self.header)

        self.cinema_bar = QWidget()
        cinema_layout = QHBoxLayout(self.cinema_bar)
        cinema_layout.setContentsMargins(9, 3, 9, 3)
        cinema_layout.addWidget(QLabel("telly"))
        self.cinema_station = QLabel("")
        cinema_layout.addWidget(self.cinema_station)
        cinema_layout.addStretch(1)
        cinema_exit = QPushButton("Exit fullscreen  ·  F11")
        cinema_exit.setObjectName("smallControl")
        cinema_exit.clicked.connect(self.fullscreen_requested)
        cinema_layout.addWidget(cinema_exit)
        self.cinema_close_button = QPushButton("×")
        self.cinema_close_button.setObjectName("closeButton")
        self.cinema_close_button.setFixedSize(34, 30)
        self.cinema_close_button.setAccessibleName("Close Telly")
        self.cinema_close_button.setToolTip("Close Telly")
        self.cinema_close_button.clicked.connect(self.close_requested)
        cinema_layout.addWidget(self.cinema_close_button)
        self.cinema_bar.hide()
        self.main_layout.addWidget(self.cinema_bar)

        self.body_layout = QHBoxLayout()
        self.body_layout.setSpacing(17)
        self.bezel = QFrame()
        self.bezel.setObjectName("bezel")
        self.bezel_layout = QVBoxLayout(self.bezel)
        self.bezel_layout.setContentsMargins(12, 12, 12, 12)
        self.bezel_layout.setSpacing(0)
        self.display_panel = QWidget()
        self.display_panel.setObjectName("screen")
        self.display_panel.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.screen_layout = QVBoxLayout(self.display_panel)
        self.screen_layout.setContentsMargins(0, 0, 0, 0)
        self.screen_layout.setSpacing(0)
        self.screen_placeholder = QWidget()
        placeholder_layout = QVBoxLayout(self.screen_placeholder)
        placeholder_layout.setContentsMargins(40, 40, 40, 40)
        placeholder_layout.addStretch(1)
        placeholder_title = QLabel("An evening in.")
        placeholder_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        placeholder_title.setStyleSheet("font-family: 'DejaVu Serif'; font-size: 28px; color: #e0d9c8;")
        placeholder_layout.addWidget(placeholder_title)
        placeholder_hint = QLabel("Choose a channel to open its official live player.")
        placeholder_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        placeholder_hint.setWordWrap(True)
        placeholder_hint.setStyleSheet("font-size: 12px; color: #8c9686; padding: 8px;")
        placeholder_layout.addWidget(placeholder_hint)
        placeholder_layout.addStretch(1)
        self.screen_layout.addWidget(self.screen_placeholder)
        self.bezel_layout.addWidget(self.display_panel)
        self.body_layout.addWidget(self.bezel, 1)

        self.controls = QFrame()
        self.controls.setObjectName("controlPanel")
        self.controls.setFixedWidth(251)
        controls_layout = QVBoxLayout(self.controls)
        controls_layout.setContentsMargins(13, 10, 13, 10)
        controls_layout.setSpacing(7)
        channels_header = QHBoxLayout()
        channel_label = QLabel("CHANNELS")
        channel_label.setStyleSheet("color: #d0c7ad; font-size: 10px; font-weight: 600; letter-spacing: 2px;")
        channels_header.addWidget(channel_label)
        channels_header.addStretch(1)
        self.power_light = QLabel("● POWER ON")
        self.power_light.setStyleSheet("color: #b7cb87; font-size: 9px; letter-spacing: 1px;")
        channels_header.addWidget(self.power_light)
        controls_layout.addLayout(channels_header)
        channel_scroll = QScrollArea()
        channel_scroll.setWidgetResizable(True)
        channel_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        channel_scroll.setMinimumHeight(80)
        channel_list = QWidget()
        channel_list.setObjectName("channelList")
        channel_list_layout = QVBoxLayout(channel_list)
        channel_list_layout.setContentsMargins(0, 0, 5, 0)
        channel_list_layout.setSpacing(6)
        for channel in channels:
            button = ChannelButton(channel)
            channel_id = str(channel["id"])
            button.clicked.connect(lambda checked=False, selected_id=channel_id: self.channel_selected.emit(selected_id))
            self.channel_buttons[channel_id] = button
            channel_list_layout.addWidget(button)
        channel_list_layout.addStretch(1)
        channel_scroll.setWidget(channel_list)
        controls_layout.addWidget(channel_scroll, 1)

        tuning_label = QLabel("TUNING")
        tuning_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        tuning_label.setStyleSheet("font-size: 9px; letter-spacing: 2px; color: #ada78e;")
        controls_layout.addWidget(tuning_label)
        dial_row = QHBoxLayout()
        dial_row.setSpacing(6)
        previous = QPushButton("−")
        previous.setAccessibleName("Previous channel")
        previous.setToolTip("Previous channel")
        previous.setFixedSize(44, 39)
        previous.clicked.connect(self.previous_requested)
        next_button = QPushButton("+")
        next_button.setAccessibleName("Next channel")
        next_button.setToolTip("Next channel")
        next_button.setFixedSize(44, 39)
        next_button.clicked.connect(self.next_requested)
        self.dial = TuningDial()
        self.dial.stepped.connect(self._dial_step)
        dial_row.addStretch(1)
        dial_row.addWidget(previous)
        dial_row.addWidget(self.dial)
        dial_row.addWidget(next_button)
        dial_row.addStretch(1)
        controls_layout.addLayout(dial_row)
        power_row = QHBoxLayout()
        power_row.setSpacing(8)
        self.power_button = QPushButton("⏻  Stop")
        self.power_button.setObjectName("powerButton")
        self.power_button.setToolTip("Stop playback")
        self.power_button.clicked.connect(self.power_requested)
        fullscreen = QPushButton("Fullscreen")
        fullscreen.setToolTip("Fullscreen · F11")
        fullscreen.clicked.connect(self.fullscreen_requested)
        power_row.addWidget(self.power_button, 1)
        power_row.addWidget(fullscreen, 1)
        controls_layout.addLayout(power_row)
        utility_row = QHBoxLayout()
        utility_row.setSpacing(6)
        self.signin_button = QPushButton("Sign in")
        self.signin_button.setObjectName("signinButton")
        self.signin_button.setToolTip("Sign in to this broadcaster in Chrome, then return to Telly")
        self.signin_button.clicked.connect(self.signin_requested)
        reload_button = QPushButton("Reload")
        reload_button.setObjectName("smallControl")
        reload_button.setAccessibleName("Reload player")
        reload_button.setToolTip("Reload player")
        reload_button.clicked.connect(self.reload_requested)
        help_button = QPushButton("Help")
        help_button.setObjectName("smallControl")
        help_button.clicked.connect(self.help_requested)
        utility_row.addWidget(self.signin_button, 1)
        utility_row.addWidget(reload_button, 1)
        utility_row.addWidget(help_button, 1)
        controls_layout.addLayout(utility_row)
        self._signin_disabled_controls = (
            channel_scroll, previous, next_button, self.dial, self.power_button,
            fullscreen, reload_button, self.signin_button, cinema_exit,
        )
        grille = QLabel("━━━━━━━━━━━━━━━━━━━━\n━━━━━━━━━━━━━━━━━━━━\n━━━━━━━━━━━━━━━━━━━━")
        grille.setAlignment(Qt.AlignmentFlag.AlignCenter)
        grille.setStyleSheet("color: #131a10; font-size: 9px; letter-spacing: 2px; line-height: 3px;")
        grille.setFixedHeight(12)
        controls_layout.addWidget(grille)
        self.body_layout.addWidget(self.controls)
        self.main_layout.addLayout(self.body_layout, 1)

        self.footer = QWidget()
        footer_layout = QHBoxLayout(self.footer)
        footer_layout.setContentsMargins(5, 0, 5, 0)
        footer_layout.setSpacing(18)
        self.status_label = ElidedLabel()
        self.status_label.setStyleSheet("color: #d3c5ab; font-size: 11px;")
        self.status_label.setText("Choose a channel. Sign in securely with the broadcaster when asked.")
        footer_layout.addWidget(self.status_label, 1)
        self.maker_mark = QLabel("OFFICIAL PLAYERS  /  LOCAL SIGN-IN")
        self.maker_mark.setStyleSheet("color: #b19c7d; font-size: 9px; letter-spacing: 1px;")
        footer_layout.addWidget(self.maker_mark)
        self.main_layout.addWidget(self.footer)
        directions = {
            "left": Qt.Edge.LeftEdge, "right": Qt.Edge.RightEdge,
            "top": Qt.Edge.TopEdge, "bottom": Qt.Edge.BottomEdge,
            "top_left": Qt.Edge.TopEdge | Qt.Edge.LeftEdge,
            "top_right": Qt.Edge.TopEdge | Qt.Edge.RightEdge,
            "bottom_left": Qt.Edge.BottomEdge | Qt.Edge.LeftEdge,
            "bottom_right": Qt.Edge.BottomEdge | Qt.Edge.RightEdge,
        }
        self.resize_handles = {}
        for name, edges in directions.items():
            handle = EdgeResizeHandle(edges, self, visible_grip=name == "bottom_right")
            handle.setObjectName("resize_" + name)
            self.resize_handles[name] = handle
        self.resize_grip = self.resize_handles["bottom_right"]
        self._position_resize_handles()

    def _position_resize_handles(self):
        if not hasattr(self, "resize_handles"):
            return
        width, height, edge, corner = self.width(), self.height(), 7, 16
        positions = {
            "left": (0, corner, edge, height - 2 * corner),
            "right": (width - edge, corner, edge, height - 2 * corner),
            "top": (corner, 0, width - 2 * corner, edge),
            "bottom": (corner, height - edge, width - 2 * corner, edge),
            "top_left": (0, 0, corner, corner),
            "top_right": (width - corner, 0, corner, corner),
            "bottom_left": (0, height - corner, corner, corner),
            "bottom_right": (width - corner, height - corner, corner, corner),
        }
        for name, handle in self.resize_handles.items():
            handle.setGeometry(*positions[name])
            handle.setVisible(not self.cinema)
            handle.raise_()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._position_resize_handles()

    def _dial_step(self, step):
        if self.signing_in:
            return
        if step < 0:
            self.previous_requested.emit()
        else:
            self.next_requested.emit()

    def set_channel(self, channel_id: str):
        """Select a station without emitting a user channel-change signal."""
        channel_id = str(channel_id)
        if channel_id not in self.channels:
            return
        self.current_channel_id = channel_id
        for item_id, button in self.channel_buttons.items():
            button.setChecked(item_id == channel_id)
        channel = self.channels[channel_id]
        self.dial.channel_number = str(channel["number"]).zfill(2)
        self.dial.update()
        self.station_display.setText(f"{self.dial.channel_number}  /  {channel['name'].upper()}")
        self.cinema_station.setText(f"·  {channel['name']}")

    def set_status(self, text: str):
        self.status_label.setText(SIGNIN_STATUS if self.signing_in else text)

    def set_signing_in(self, signing_in: bool):
        """Lock viewing controls while the controller owns a separate login window.

        Call this before launching Chrome to prevent duplicate login clicks. The
        controller must also guard its own keyboard shortcuts and channel methods.
        Help stays usable. Browser creation, fullscreen exit and resuming playback
        remain the controller's responsibility.
        """
        signing_in = bool(signing_in)
        if signing_in == self.signing_in:
            return
        if signing_in:
            self._status_before_signin = self.status_label.full_text
        self.signing_in = signing_in
        for control in self._signin_disabled_controls:
            control.setEnabled(not signing_in)
        self.maker_mark.setVisible(not signing_in)
        self.set_status(SIGNIN_STATUS if signing_in else self._status_before_signin)

    def set_powered(self, powered: bool):
        """Reflect controller playback state; never starts or stops video itself."""
        self.powered = bool(powered)
        self.power_button.setText("⏻  Stop" if powered else "⏻  Tune in")
        self.power_button.setToolTip("Stop playback" if powered else "Open the selected channel")
        self.power_light.setText("● POWER ON" if powered else "● STANDBY")
        self.power_light.setStyleSheet(f"color: {'#b7cb87' if powered else '#cc9d64'}; font-size: 9px; letter-spacing: 1px;")

    def set_cinema(self, enabled: bool):
        """Hide the cabinet controls; controller owns the actual window fullscreen."""
        self.cinema = bool(enabled)
        self.header.setVisible(not enabled)
        self.controls.setVisible(not enabled)
        self.footer.setVisible(not enabled)
        self.cinema_bar.setVisible(enabled)
        self.main_layout.setContentsMargins(0, 0, 0, 0) if enabled else self.main_layout.setContentsMargins(18, 12, 18, 12)
        self.main_layout.setSpacing(0 if enabled else 9)
        self.body_layout.setSpacing(0 if enabled else 17)
        edge = 0 if enabled else 12
        self.bezel_layout.setContentsMargins(edge, edge, edge, edge)
        self.bezel.setStyleSheet("background: #080a09; border: none; border-radius: 0;" if enabled else "")
        self._position_resize_handles()
        self.update()
